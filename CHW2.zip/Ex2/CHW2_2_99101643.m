
X = TrainData(1:3, 1:end);
y = TrainData(4,1:end);

% Visualize the 3D data with different colors for each class
figure;
scatter3(X(1, y == 0), X(2, y == 0), X(3, y == 0), 'r', 'o');
hold on;
scatter3(X(1, y == 1), X(2, y == 1), X(3, y == 1), 'b', '^');
hold on;
xlabel('Feature 1');
ylabel('Feature 2');
zlabel('Feature 3');
legend('Class 0', 'Class 1');
title('3D Data Visualization');
X_test = TestData(1:3, 1:end);

%% A & B
%[Testlabel_a , net] = Neural_Network(1,X,y,X_test); %A
%save('Testlabel_a.mat','Testlabel_a')
[predicted_classes1,predicted_classes0] = Neural_Network2(1,2,X,y,X_test); %B
Testlabel_b = [predicted_classes1;predicted_classes0]';
save('Testlabel_b.mat','Testlabel_b')

function [predicted_classes , net]= Neural_Network(hiddenLayerSize ,X,y,X_test)
% Create a Neural Network classifier
net = patternnet(hiddenLayerSize);
net = configure(net,X,y);
% Train the classifier
net = train(net, X, y);
output = net(X_test);
%nnstart

  
% Test the classifier
predicted_classes = round(output); % Round to the nearest integer (0 or 1)

scatter3(X_test(1, predicted_classes == 0), X_test(2, predicted_classes == 0), X_test(3, predicted_classes == 0), 'g', 'o');
hold on;
scatter3(X_test(1, predicted_classes == 1), X_test(2, predicted_classes == 1),X_test(3, predicted_classes == 1), 'y', '^');
hold on;
xlabel('Feature 1');
ylabel('Feature 2');
zlabel('Feature 3');
legend('Class 0', 'Class 1','TestData(Class 0)', 'TestData(Class 1)');
title('3D Data Visualization');

end

function [predicted_classes1,predicted_classes0]= Neural_Network2(hiddenLayerSize , output_neurons,X,y,X_test)
% Create a Neural Network classifier
net = patternnet(hiddenLayerSize);
net = configure(net,X,y);

%net.Layers{end}.size=3;   
%net.outputs	=2;
%net.numLayers = 3;

% Train the classifier
net = train(net, X, y);

output = net(X_test);

predicted_classes1 = [];
predicted_classes0= [];
% Test the classifier
%predicted_classes = net(X_test');
predicted_classes = round(output); % Round to the nearest integer (0 or 1)


if output_neurons > 1
    
    for i = 1 : 90
    output2(i) = 1 - output(i);
        predicted_classes1(i) =output(i);
        predicted_classes0(i) = output2(i);
    end
end
scatter3(X_test(1, predicted_classes == 0), X_test(2, predicted_classes == 0), X_test(3, predicted_classes == 0), 'g', 'o');
hold on;
scatter3(X_test(1, predicted_classes == 1), X_test(2, predicted_classes == 1),X_test(3, predicted_classes == 1), 'y', '^');
hold on;
xlabel('Feature 1');
ylabel('Feature 2');
zlabel('Feature 3');
legend('Class 0', 'Class 1','TestData(Class 0)', 'TestData(Class 1)');
title('3D Data Visualization');

end








