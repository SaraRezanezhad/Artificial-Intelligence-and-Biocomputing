%A
X = speed;
Y= NOemission;
Z= fuelrate;
scatter3(X,Y,Z)
xlabel('speed');
ylabel('NOemission');
zlabel('fuelrate');
%% B
X_train = X(1:700) ;
Y_train = Y(1:700);
Z_train = Z(1:700);
X_valid = X(701:end) ;
Y_valid = Y(701:end) ;
Z_valid = Z(701:end) ;

scatter3(X_train,Y_train,Z_train , 'b')
hold on;
scatter3(X_valid,Y_valid,Z_valid, 'r')

xlabel('speed');
ylabel('NOemission');
zlabel('fuelrate');
legend('train data', 'validiation data');

%% c
data = [X_train ;Y_train]';
mdl = fitlm(data,Z_train);
disp(mdl)

data2 = [X_valid ;Y_valid]';
mdl2 = fitlm(data2,Z_valid);

% رسم hyperplane
coeffs = mdl.Coefficients.Estimate; % ضرایب مدل
[x, y] = meshgrid(min(X_train):max(X_train), min(Y_train):max(Y_train));
z = @(X_train,Y_train) coeffs(1) + coeffs(2)*X_train + coeffs(3)*Y_train;
fsurf(z, [0 2000 0 2000]);
mse_training = mse(predict(mdl,data), Z_train);
mse_validation = mse(predict(mdl2,data2), Z_valid);
disp("training mse :"+mdl.MSE)
disp("validation mse :"+mdl2.MSE)

%% D

scatter3(X_train,Y_train,Z_train , 'b')
hold on;
scatter3(X_valid,Y_valid,Z_valid, 'r')
xlabel('speed');
ylabel('NOemission');
zlabel('fuelrate');

traininglog_Z = log((max(Z_train)-Z_train)./Z_train);

TAB = [X_train(30:700); Y_train(30:700)]';
mdl3 = fitlm(TAB,traininglog_Z(30:700));
a = mdl3.Coefficients(1,1);
b = mdl3.Coefficients(2,1);
c = mdl3.Coefficients(3,1);

a_as_matrix = table2array(a);
a_double = double(a_as_matrix);

b_as_matrix = table2array(b);
b_double = double(b_as_matrix);

c_as_matrix = table2array(c);
c_double = double(c_as_matrix);

[F1, F2] = meshgrid(min(X_train):50:max(X_train), min(Y_train):50:max(Y_train));
zl = max(Z_train)./(1+exp(b_double*F1 + c_double*F2 + a_double));
surf(F1, F2, zl)

LogTrain = max(Z_train)./(1+exp(a_double + b_double*X_train + c_double*Y_train));
LogValidation = max(Z_train)./(1+exp(a_double + b_double*X_valid + c_double*Y_valid));

LogTrainMSE = sum((LogTrain - Z_train).^2) / length(X_train);
disp("Logestic training mse: " + LogTrainMSE);
LogValidationMSE = sum((LogValidation - Z_valid).^2) / length(X_valid);
disp("Logestic validation mse :"+LogValidationMSE)

%% E 1 
net = patternnet(55);
net = configure(net,data',Z_train);

% Train the classifier
net = train(net,data',Z_train);
%% E 2
input = [NOemission;speed];
output = fuelrate;
nnstart













