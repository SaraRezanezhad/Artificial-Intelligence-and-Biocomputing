[X,Y] = meshgrid(0:1:1, 0:1:1);

w1 = 1; 
w2 = 1; 
T = 1; 
B = 0.1;
output = 1 ./ (1 + exp(-B*(w1*X + w2*Y - T)));

figure;
surf(X, Y, output);
xlabel('X');
ylabel('Y');
zlabel('Output');
title('نمودار خروجی با تابع فعال‌سازی logistic');

%تغییر T به صورت interactive
uicontrol('Style', 'slider', 'Min', -5, 'Max', 5, 'Value', T, 'Position', [20 20 200 20], 'Callback', {@updateWeight, 0});
uicontrol('Style', 'text', 'Position', [20 45 200 20], 'String', sprintf('T'));


% تغییر وزن‌ها به صورت interactive
uicontrol('Style', 'slider', 'Min', -5, 'Max', 5, 'Value', w1, 'Position', [20 80 200 20], 'Callback', {@updateWeight, 1});
uicontrol('Style', 'text', 'Position', [20 105 200 20], 'String', sprintf('w1'));

uicontrol('Style', 'slider', 'Min', -5, 'Max', 5, 'Value', w2, 'Position', [20 140 200 20], 'Callback', {@updateWeight, 2});
uicontrol('Style', 'text', 'Position', [20 165 200 20], 'String', sprintf('w2'));


function updateWeight(src, ~, weightIndex)
    value = src.Value;
    if weightIndex == 0
            assignin('base', sprintf('T'), value);
    else
       assignin('base', sprintf('w%d', weightIndex), value);
    end
    evalin('base', 'output = 1 ./ (1 + exp(-B*(w1*X + w2*Y- T)));');
    evalin('base', 'surf(X, Y, output);');
    evalin('base', 'set(findobj(gcf,''Type'',''text'',''String'',''T:''), ''String'', sprintf(''T: %d'', T));');
    evalin('base', 'set(findobj(gcf,''Type'',''text'',''String'',''w1:''), ''String'', sprintf(''w1: %d'', w1));');
    evalin('base', 'set(findobj(gcf,''Type'',''text'',''String'',''w2:''), ''String'', sprintf(''w2: %d'', w2));');
end










