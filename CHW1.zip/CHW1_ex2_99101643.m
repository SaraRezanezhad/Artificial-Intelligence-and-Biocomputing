%% الف
data = readtable('iris.csv');

class1 = data(data.Var5 == "Iris-setosa", :);
class2 = data(data.Var5 == "Iris-versicolor", :);
class3 = data(data.Var5 == "Iris-virginica", :);

figure;
scatter(class1.Var1, class1.Var2, 'r', 'filled');
hold on;
scatter(class2.Var1, class2.Var2, 'b', 'filled');
xlabel('Sepal Length');
ylabel('Sepal Width');
legend('Iris-setosa', 'Iris-versicolor');
title('Sepal Length vs Sepal Width');
%%
figure;
scatter(class1.Var3, class1.Var4, 'r', 'filled');
hold on;
scatter(class2.Var3, class2.Var4, 'b', 'filled');
xlabel('Petal Length');
ylabel('Petal Width');
legend('Iris-setosa', 'Iris-versicolor');
title('Petal Length vs Petal Width');

%% ب
% جدا کردن 10 نمونه تصادفی
class1 = data(data.Var5 == "Iris-setosa", :);
class2 = data(data.Var5 == "Iris-versicolor", :);
subset_class1 = class1(randperm(height(class1), 5), :);
subset_class2 = class2(randperm(height(class2), 5), :);

% ترکیب داده‌های زیرمجموعه
subset = [subset_class1; subset_class2];

% محاسبه وزن‌ها و آستانه برای TLU
X = [subset.Var1 subset.Var2];
Y = [ones(5,1); -1*ones(5,1)];
w = pinv(X)*Y;

% استفاده از TLU برای جداسازی دو کلاس
predicted_Y = X*w;

% نمایش نتایج
disp(predicted_Y);

%% ز

figure;
 subplot(2, 2, 1);
scatter3(class1.Var1, class1.Var2, class1.Var3, 'r', 'filled');
hold on;
scatter3(class2.Var1, class2.Var2, class2.Var3, 'g', 'filled');
scatter3(class3.Var1, class3.Var2, class3.Var3, 'b', 'filled');
xlabel('Sepal Length');
ylabel('Sepal Width');
zlabel('Petal Length');
legend('Setosa', 'Versicolor', 'Virginica');
title('3D Scatter Plot of Iris Data');

 subplot(2, 2, 2);
scatter3(class1.Var1, class1.Var2, class1.Var4, 'r', 'filled');
hold on;
scatter3(class2.Var1, class2.Var2, class2.Var4, 'g', 'filled');
scatter3(class3.Var1, class3.Var2, class3.Var4, 'b', 'filled');
xlabel('Sepal Length');
ylabel('Sepal Width');
zlabel('Petal Width');
legend('Setosa', 'Versicolor', 'Virginica');
title('3D Scatter Plot of Iris Data');

 subplot(2, 2, 3);
scatter3(class1.Var1, class1.Var4, class1.Var3, 'r', 'filled');
hold on;
scatter3(class2.Var1, class2.Var4, class2.Var3, 'g', 'filled');
scatter3(class3.Var1, class3.Var4, class3.Var3, 'b', 'filled');
xlabel('Sepal Length');
ylabel('Petal Width');
zlabel('Petal Length');
legend('Setosa', 'Versicolor', 'Virginica');
title('3D Scatter Plot of Iris Data');

 subplot(2, 2, 4);
scatter3(class1.Var4, class1.Var2, class1.Var3, 'r', 'filled');
hold on;
scatter3(class2.Var4, class2.Var2, class2.Var3, 'g', 'filled');
scatter3(class3.Var1, class3.Var2, class3.Var3, 'b', 'filled');
xlabel('Petal Width');
ylabel('Sepal Width');
zlabel('Petal Length');
legend('Setosa', 'Versicolor', 'Virginica');
title('3D Scatter Plot of Iris Data');



