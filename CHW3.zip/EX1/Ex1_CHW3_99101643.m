 %% A
x1 =TrainingData(1,1:400); 
x2 =TrainingData(2,1:400); 
y = TrainingLabels;
scatter(x1(y == 0) , x2(y == 0), 'b');
hold on;
scatter(x1(y == 1) , x2(y == 1), 'r');
xlabel('TrainingData');
ylabel('TrainingLabels');
legend('class0', 'class1');

%% B
X1_train = x1(121:end) ;
X2_train = x2(121:end) ;
Y_train = y(121:end);

X1_valid = x1(1:120) ;
X2_valid = x2(1:120) ;
Y_valid = y(1:120) ;

scatter(X1_train(Y_train==0),X2_train(Y_train==0), 'b')
hold on;
scatter(X1_valid(Y_valid == 0),X2_valid(Y_valid == 0), 'r')
scatter(X1_train(Y_train==1),X2_train(Y_train==1), 'y')
hold on;
scatter(X1_valid(Y_valid == 1),X2_valid(Y_valid == 1), 'g')
xlabel('TrainingData');
ylabel('TrainingLabels');
legend('TrainingData(class0)', 'ValidationData(class0)','TrainingData(class1)', 'ValidationData(class1)');

%% C
spread_values = 0.1:0.1:2; % Range of spread values to try
neuron_values = 1:2; % Range of neuron values to try
best_accuracy = 0;
best_spread = 0;
best_neurons = 0;
best_net = [];

for spread = spread_values
    for neurons = neuron_values
        net = newrb([X1_train; X2_train], Y_train, 0.0, spread, neurons);
        
        % Evaluate on validation data
        Y_pred = sim(net, [X1_valid; X2_valid]);
        Y_pred = (Y_pred >= 0.5); % Convert to binary predictions

        % Compute accuracy
        accuracy = sum(Y_pred' == Y_valid) / numel(Y_valid);
        
        if accuracy > best_accuracy
            best_accuracy = accuracy;
            best_spread = spread;
            best_neurons = neurons;
            best_net = net; % Save the best model
        end
    end
end

fprintf('Best accuracy on validation data: %f\n', best_accuracy);
fprintf('Best spread value: %f\n', best_spread);
fprintf('Best number of neurons: %d\n', best_neurons);