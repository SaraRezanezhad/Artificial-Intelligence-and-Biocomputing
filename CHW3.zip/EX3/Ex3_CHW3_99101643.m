%% A , B
% Define the number of clusters
num_clusters = 5;

% Define the fitness function for clustering using genetic algorithm
fitness_func = @(x) clustering_fitness_function(x, DataNew, num_clusters);

% Define the options for genetic algorithm
options = optimoptions('ga', 'MaxGenerations', 100, 'PopulationSize', 100);

% Run the genetic algorithm
initial_centers = datasample(DataNew', num_clusters, 'Replace', false)';  % Assuming each column is a data point

% Perform clustering using the obtained centroids
[idx_genetic, centers_genetic] = kmeans(DataNew', num_clusters, 'Start', initial_centers');

% Visualize the clustering result
figure;
gscatter(DataNew(1, :), DataNew(2, :), idx_genetic);
hold on;
plot(centers_genetic(:,1), centers_genetic(:,2), 'kx', 'MarkerSize', 15, 'LineWidth', 3);
title('Clustering Result using Genetic Algorithm');
xlabel('Feature 1');
ylabel('Feature 2');
legend('Cluster 1', 'Cluster 2', 'Cluster 3', 'Cluster 4', 'Cluster 5', 'Cluster Centers');
hold off;

%% C ,D
% Define the options for PSO
options_pso = optimoptions('particleswarm', 'SwarmSize', 100, 'MaxIterations', 100);

% Run the PSO algorithm
[x_pso, fval_pso] = particleswarm(fitness_func, size(DataNew', 2), [], [], options_pso);

% Perform clustering using the obtained centroids from PSO
idx_pso = kmeans(DataNew, num_clusters, 'Start', x_pso);

% Visualize the clustering result
figure;
gscatter(DataNew(1, :), DataNew(2, :), idx_pso);
hold on;
plot(x_pso(:,1), x_pso(:,2), 'kx', 'MarkerSize', 15, 'LineWidth', 3);
title('Clustering Result using PSO Algorithm');
xlabel('Feature 1');
ylabel('Feature 2');
legend('Cluster 1', 'Cluster 2', 'Cluster 3', 'Cluster 4', 'Cluster 5', 'Cluster Centers');
hold off;





function fitness = clustering_fitness_function(centroids, data, num_clusters)
    % Perform clustering using the centroids
    [~, centers] = kmeans(data, num_clusters, 'Start', centroids);
    
    % Calculate the sum of distances from data points to their respective cluster centers
    distances = pdist2(data, centers);
    [~, assigned_cluster] = min(distances, [], 2);
    fitness = sum(min(distances, [], 2));
end
