% A, B, C
% Set the number of clusters
num_clusters = 5;
% Set initial cluster centers 
initial_centers = datasample(DataNew', num_clusters, 'Replace', false)'; 
%  the custom K-means algorithm
[clusters_custom, centers_custom] = myKMeans(DataNew', num_clusters, initial_centers);

figure;
gscatter(DataNew(1, :), DataNew(2, :), clusters_custom);
title(' Clustering Result');
xlabel('Feature 1');
ylabel('Feature 2');
legend('Cluster 1', 'Cluster 2', 'Cluster 3', 'Cluster Centers');
hold on;
scatter(centers_custom(:, 1), centers_custom(:, 2), 100, 'k', 'filled');

%% D
num_clusters = 6;

initial_centers = datasample(DataNew', num_clusters, 'Replace', false)';  % Assuming each column is a data point

% Using MATLAB's kmeans command

[idx_kmeans, centers_kmeans] = kmeans(DataNew', num_clusters, 'Start', initial_centers');
% Scatter plot of the data points
figure;
gscatter(DataNew(1,:), DataNew(2,:), idx_kmeans);
hold on;

% Plot the cluster centers
plot(centers_kmeans(:,1), centers_kmeans(:,2), 'kx', 'MarkerSize', 15, 'LineWidth', 3);
title('K-Means Clustering Result');
xlabel('Feature 1');
ylabel('Feature 2');
legend('Cluster 1', 'Cluster 2', 'Cluster 3', 'Cluster Centers');
hold off;


function [clusters, cluster_centers] = myKMeans(data, k, initial_centers)
    % k: Number of clusters
    % initial_centers: Initial cluster centers matrix
    
    % Initialize cluster centers
cluster_centers = zeros(k, size(data, 2));
for i = 1:k
    cluster_centers(i, :) = data(randi(size(data, 1)), :);
end
    
    % Maximum number of iterations (you can change this based on convergence criteria)
    max_iterations = 100;
    
    % Main K-means algorithm
    for iter = 1:max_iterations
        % Assignment step: Assign each data point to the nearest cluster center
        distances = pdist2(data, cluster_centers, 'euclidean'); % Calculate distances
        [~, cluster_assignments] = min(distances, [], 2); % Assign points to clusters
        %disp(cluster_assignments);
        % Update step: Update cluster centers based on the assigned points
        for i = 1:k
            cluster_centers(i, :) = mean(data(cluster_assignments == i, :), 1);
        end
    end
    
    % Output the final cluster assignments and cluster centers
    clusters = cluster_assignments;
end
